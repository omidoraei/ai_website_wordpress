AURORA AI - ELEMENTOR TEMPLATE KIT
==================================

This archive is the Elementor "Export Kit" style package:

  manifest.json          kit manifest (what is inside, Elementor version)
  site-settings.json     global colors, global fonts, layout, button + form styles
  templates-source/*     every template as a standalone Elementor document

What this kit archive does
--------------------------
Importing it applies the Aurora design system to your site in one step:
global colors, global fonts, content width, breakpoints, heading/body/link
styles, button styles and form-field styles.

Recommended import order
------------------------
1. Templates > Saved Templates > Import Templates  ->  aurora-ai-templates.zip
   (this adds all 40 templates to your library)
2. Elementor > Tools > Import / Export Kit  ->  Import Kit  ->  this file
   (this applies the design system) - or apply the globals by hand following
   docs/02-design-system.md if your Elementor version is older than 3.x
3. Templates > Theme Builder: create a Header, a Footer, a Single Post, an
   Archive, a Search Results and a Popup document and insert the matching
   template from My Templates, then set the display conditions.
4. Create your pages (Home, About, Services, Case Studies, Pricing, Journal,
   Contact, 404) and drop the matching page template into each one.

Every file in templates-source/ is a standalone Elementor document - import
only what you need. Full instructions: docs/01-installation.md
